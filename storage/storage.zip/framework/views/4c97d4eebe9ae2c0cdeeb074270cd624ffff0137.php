<footer class="main-footer">
    <strong>Copyright &copy; 2020 Powered By WabLoan Lending Company Limited.</strong>
    All rights reserved.
    
  </footer><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\includes\footer.blade.php ENDPATH**/ ?>