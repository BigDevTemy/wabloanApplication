<!DOCTYPE html>
<html>
<head>
	<title>WabLoan | Administrator|Login</title>
</head>
<link rel="stylesheet" href="<?php echo e(asset('login.css')); ?>">
<body>
<div class="login">
	<h3 style="color: #fff">WabLoan AdminLogin</h3>
    <form method="post">
    	<input type="text" name="u" placeholder="Username" required="required" />
        <input type="password" name="p" placeholder="Password" required="required" />
        <button type="submit" class="btn btn-primary btn-block btn-large">Login</button>
    </form>
</div>
</body>
</html><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\loginold.blade.php ENDPATH**/ ?>