
<?php $__env->startSection('content'); ?>
<style type="text/css">
  
  /* Tabs*/
section {
    padding: 5px ;
}

section .section-title {
    text-align: center;
    color: #007b5e;
    margin-bottom: 20px;
    text-transform: uppercase;
}
#tabs{
  background-color: #f3f3f3;
    color: #003300;
    font-family: 'candara';
    font-size: 14px;
}
#tabs h6.section-title{
    color: #fff;
}

#tabs .nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link.active {
    color: #000000;
    background-color: transparent;
    border-color: transparent transparent #000000;
    border-bottom: 4px solid !important;
    font-size: 12px;

    font-weight: bold;
}
#tabs .nav-tabs .nav-link {
    border: 1px solid transparent;
    border-top-left-radius: .25rem;
    border-top-right-radius: .25rem;
    color: #000;
    font-size: 12px;
    font-family: 'candara';
}
</style>
<div  id="loader"></div>
<section class="content">
  <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <div class="m-0 text-dark" style="font-size: 16px;font-weight: bold">Due Date Order</div>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
      <div class="container-fluid">
        <!-- Info boxes -->
        
        <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fa-cog"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"> Loan Repayment Order</span>
                <span class="info-box-number">
                  <?php echo e(count($get_due_date_loans)); ?>

                  <small></small>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          
         
        </div>
        <!-- /.row -->

        <!--Tab Navigation -->
        <div class="row">
          <section id="tabs">
  <div class="container">
    
    <div class="row">
      <div class="col-xs-12 ">
        <nav>
          <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
            
            <?php if(!empty($get_due_date_loans)): ?>
            <?php $__currentLoopData = $get_due_date_loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addtab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false"><input type="hidden" value="<?php echo e($addtab->userId); ?>"/>Details(<?php echo e($addtab->loanID); ?>)</a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
          </div>
        </nav>
        <form method="POST" action="<?php echo e(route('assignReviewJob')); ?>">
        <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
          
            <?php echo csrf_field(); ?>
          <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
          <?php if($errors->any()): ?>
                                          <div class="alert alert-info" style="width: 100%;font-size: 14">
                                                <ul>
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($error); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
          
          <div class="card">
            <?php if(count($get_due_date_loans) > 0): ?>
            <div class="card-header border-transparent">
                  <h3 class="card-title">Order Review</h3>

                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                  </div>

          <div class="card-body p-0" style="background-color: #fff">
                <div class="table-responsive">
                  <?php if(!empty($get_due_date_loans)): ?>

                    <table class="table m-0">
                      <thead>
                      <tr>
                         <th>#</th>
                        <th>Loan id</th>
                        <th>Fullname</th>
                        <th>Loan Amount</th>
                        <th>Loan Tenure</th>
                        <th>Loan Total</th>
                        <th>Due Date</th>
                      </tr>
                      </thead>
                      <tbody>
            <?php $__currentLoopData = $get_due_date_loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td>#</td>
                        <td><a href="#"><?php echo e($pending->loanID); ?></a></td>
                        <td><?php echo e($pending->user->fname); ?> <?php echo e($pending->user->lname); ?></td>
                        <td><?php echo e($pending->loan_amount); ?></td>
                        <td><?php echo e($pending->loan_tenure); ?></td>
                        <td><?php echo e($pending->loan_total); ?></td>
                        <td><?php if($pending->review_status == "pending"): ?><span class="badge badge-warning">pending review</span> <?php else: ?> <span class="badge badge-success"><?php echo e($pending->due_date); ?></span> <?php endif; ?></td>
                        
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      
                    <?php endif; ?>
                      </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
              </div>
              <?php endif; ?>
            </div>


          </div>
          
          
          
          <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
          
        
          </div>
          <div id="nav-profile_details">
            
          </div>
        </div>
        <form>

      
      </div>
    </div>
  </div>
</section>
      </div>

        </div>
        
        
        <!--Tab Navigation Ends -->
        <!--Table Starts-->

        
    </div>


        

    </section>
<script type="text/javascript">


  $(document).ready(function(){
  $loandetails = <?php echo json_encode($get_due_date_loans, 15, 512) ?>;
  $userdetails = <?php echo json_encode($getallUsers, 15, 512) ?>;
  $companydetails = <?php echo json_encode($getall_companyDetails, 15, 512) ?>;
  $bankdetails = <?php echo json_encode($getall_bankDetails, 15, 512) ?>;
  $loanhistory = <?php echo json_encode($loan_history, 15, 512) ?>;



    $(".nav-item").click(function(){
      
      $("#nav-profile").val('');
      $("#nav-profile_details").html('');
      $getId = $(this).find('input').attr('value').valueOf();
      

      var filterUserDetails = $userdetails.filter(function(el){
        return el.userid == $getId;
      })
      var filterCompanyDetails = $companydetails.filter(function(el){
        return el.userid == $getId;
      })
      var filterBankDetails = $bankdetails.filter(function(el){
        return el.userid == $getId;
      })
      var filterLoanDetails = $loanhistory.filter(function(el){
        return el.userId == $getId;
      })
      console.log('Filter',filterLoanDetails);
$new_tab  = '<nav><div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist"><a class="nav-item_personal nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false" id="personalInformation">Personal Information</a><a class="nav-item_company nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Company Information</a><a class="nav-item_bank nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Bank Details Information</a><a class="nav-item_loan nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Loan History</a><a class="nav-item_action nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Action</a></div></nav>'
    

    $('#nav-profile').html($new_tab);


    $(".nav-items").on('click',function(){
      console.log('Filter',filterUserDetails)
      $.each(filterUserDetails,function(index,value){
    
    
      $nav_details = '<table class="table m-0"><thead><tr><th>id</th><th>Firstname</th><th>Lastname</th><th>Email</th><th>Date Of Birth</th><th>Phonenumber</th><th>Marital Status</th><th>BVN</th><th>State of Origin</th><th>Family Contact Number</th><th>Friend Contact Number</th><th>Credit Limit</th><th>Userid</th></tr></thead><tbody><tr><td>'+value['id']+'</td><td>'+value['fname']+'</td><td>'+value['lname']+'</td><td>'+value['email']+'</td><td>'+value['dob']+'</td><td>'+value['Phonenumber']+'</td><td>'+value['marital_status']+'</td><td>'+value['bvn']+'</td><td>Osun State</td><td>'+value['familycontact']+'</td><td>'+value['friendcontact']+'</td><td>'+value['creditlimit']+'</td><td>'+value['userid']+'</td></tr></tbody></table>'
    
    
    $('#nav-profile_details').html($nav_details);

  })
      
    })


    $(".nav-item_personal").on('click',function(){
      console.log('Filter',filterUserDetails)
      $.each(filterUserDetails,function(index,value){
    
    
      $nav_details = '<img src="<?php echo e(asset("wabloan_selfie/1602177336C3C2DC5E-9264-4463-83F4-3A7AA6D920E0.jpg")); ?>" style="width:200px;height:200px;border-radius:50%"/><table class="table m-0"><thead><tr><th>id</th><th>Firstname</th><th>Lastname</th><th>Email</th><th>DOB</th><th>Phonenumber</th><th>Marital Status</th><th>BVN</th><th>State of Origin</th><th>Family Contact Number</th><th>Friend Contact Number</th><th>Credit Limit</th><th>Userid</th></tr></thead><tbody><tr><td>'+value['id']+'</td><td>'+value['fname']+'</td><td>'+value['lname']+'</td><td>'+value['email']+'</td><td>'+value['dob']+'</td><td>'+value['phonenumber']+'</td><td>'+value['marital_status']+'</td><td>'+value['bvn']+'</td><td>Osun State</td><td>'+value['familycontact']+'</td><td>'+value['friendcontact']+'</td><td>'+value['creditlimit']+'</td><td>'+value['userid']+'</td></tr></tbody></table>'
    
    
    $('#nav-profile_details').html($nav_details);

  })
      
    })

    $(".nav-item_company").on('click',function(){
       console.log('Filtercompany',filterCompanyDetails)
     $.each(filterCompanyDetails,function(index,value){
    
    
      $nav_details = '<table class="table m-0"><thead><tr><th>id</th><th>Company Name</th><th>Company Address</th><th>Company State Location</th><th>Company Contact Number</th><th>Employement Type</th><th>Salary Range</th></tr></thead><tbody><tr><td>'+value['id']+'</td><td>'+value['company_name']+'</td><td>'+value['company_address']+'</td><td>'+value['company_state']+'</td><td>'+value['company_contact']+'</td><td>'+value['employment_type']+'</td><td>'+value['salary_range']+'</td></tr></tbody></table>'
    
    
    $('#nav-profile_details').html($nav_details);

  })
      
    })

    $(".nav-item_bank").on('click',function(){
       
     $.each(filterBankDetails,function(index,value){
      $nav_details = '<table class="table m-0"><thead><tr><th>id</th><th>Account Number</th><th>Account Name</th><th>Bank Code</th><th>Card Pan</th><th>Card TYPE</th></tr></thead><tbody><tr><td>'+value['id']+'</td><td>'+value['account_number']+'</td><td>'+value['account_name']+'</td><td>'+value['bank_code']+'</td><td>'+value['card_pan']+'</td><td>'+value['card_type']+'</td></tr></tbody></table>'
    $('#nav-profile_details').html($nav_details);

  })
      
    })

  $(".nav-item_action").on('click',function(){
       
    $action = '<div style="width:100%"><br/><div class="row"><input type="text" id="remark" placeholder="Comment" class="form-control"/></div><br/><div  class="row"><div class="col-6"><button class="btn btn-success btn-block" id="approve">Approve</button></div><div class="col-6"><button type="submit" class="btn btn-danger btn-block" id="decline">Decline</button></div></div></div>'

    $('#nav-profile_details').html($action);  

    $("#approve").click(function(e){
      e.preventDefault();

        $remark = document.getElementById('remark').value;
      if($remark !="" ){

          $.ajax({
             url:'<?php echo e(route("approve_loan")); ?>',
             type:'post',
             headers: { 'X-CSRF-TOKEN': $('input[name=_token]').val() },
             beforeSend:function(){
              
              $("#approve").attr('disabled',true);
              $("#loader").addClass('se-pre-con');
             },
             data:{
                    userid:$getId,
                    remark :$remark,
                    "_token": "<?php echo e(csrf_token()); ?>"        
                  },
            success:function(data){
                    $(".se-pre-con").fadeOut("slow")
                    console.log(data);
               if(data == "Loan has been Updated Successfully" || data== "Loan has been Updated Successfully..SMS Notification to the Customer FAILED"){
                alert(data);
                window.location="/review_member/assigned/loanreview"
               }
             },
            error:function(object, status, e){
                
                    $(".se-pre-con").fadeOut("slow")
                      alert(e);
                    console.log(e);
            }
        })


      }
      else{
        alert('Remark Field is Required');
      }


        
      })
      
    })

  $(".nav-item_loan").on('click',function(){
      if(filterLoanDetails !="" ){
         $.each(filterLoanDetails,function(index,value){
  
       $loan = '<table class="table m-0"><thead><tr><th>id</th><th>LoanID</th><th>Loan Amount</th><th>Loan Interest</th><th>Loan Tenure</th><th>Loan Total</th><th>Loan Status</th><th>Review Status</th><th>Repayment Indicator</th><th>Created At</th><th>Updated At</th><th>AssignTo</th></tr></thead><tbody><tr><td>'+value['id']+'</td><td>'+value['loanID']+'</td><td>'+value['loan_amount']+'</td><td>'+value['loan_interest']+'</td><td>'+value['loan_tenure']+'</td><td>'+value['loan_total']+'</td><td>'+value['loan_status']+'</td><td>'+value['review_status']+'</td><td>'+value['repayment_level']+'</td><td>'+value['created_at']+'</td><td>'+value['updated_at']+'</td><td>'+value['assignTo']+'</td></tr></tbody></table>'

      $('#nav-profile_details').html($loan);  
  
  })
      }
      else{
        $('#nav-profile_details').html('<h3>NO LOAN HISTORY</h3>');
      }
     

      
      
    })

      
    });
    

    

    
    


  })
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('wabloan.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\due_date_loan.blade.php ENDPATH**/ ?>