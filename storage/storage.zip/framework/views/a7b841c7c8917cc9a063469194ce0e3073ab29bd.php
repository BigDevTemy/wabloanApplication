
<?php $__env->startSection('content'); ?>
<style type="text/css">
  
  /* Tabs*/
section {
    padding: 5px ;
}

section .section-title {
    text-align: center;
    color: #007b5e;
    margin-bottom: 20px;
    text-transform: uppercase;
}
#tabs{
  background-color: #f3f3f3;
    color: #003300;
    font-family: 'candara';
    font-size: 14px;
}
#tabs h6.section-title{
    color: #fff;
}

#tabs .nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link.active {
    color: #000000;
    background-color: transparent;
    border-color: transparent transparent #000000;
    border-bottom: 4px solid !important;
    font-size: 12px;

    font-weight: bold;
}
#tabs .nav-tabs .nav-link {
    border: 1px solid transparent;
    border-top-left-radius: .25rem;
    border-top-right-radius: .25rem;
    color: #000;
    font-size: 12px;
    font-family: 'candara';
}
</style>
<div  id="loader"></div>
<section class="content">
  <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <div class="m-0 text-dark" style="font-size: 16px;font-weight: bold">Customer Care Dashboard</div>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
      <div class="container-fluid">
        <!-- Info boxes -->
        
        <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fa-cog"></i></span>

              <div class="info-box-content">
                <span class="info-box-text"> Opened Tickets</span>
                <span class="info-box-number">
                  <?php echo e(count($getPendingTickets)); ?>

                  <small></small>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          
         
        </div>
        <!-- /.row -->

        <!--Tab Navigation -->
        <div class="row">
          <section id="tabs" style="width:80%">
  <div class="container">
    
    <div class="row">
      <div class="col-lg-12 ">
        <nav>
          <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
            <?php if(count($getPendingTickets)>0): ?><a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Review Order</a>
            <?php endif; ?>
            <?php if(!empty($getPendingTickets)): ?>
            <?php $__currentLoopData = $getPendingTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addtab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false"><input type="hidden" value="<?php echo e($addtab->ticket_id); ?>" name="<?php echo e($addtab->userid); ?>"/>Details(<?php echo e($addtab->ticket_id); ?>)</a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
          </div>
        </nav>
        
        <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
          
            <?php echo csrf_field(); ?>
          <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
          <?php if($errors->any()): ?>
                                          <div class="alert alert-info" style="width: 100%;font-size: 14">
                                                <ul>
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($error); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
          
          <div class="card">
            <?php if(count($getPendingTickets) > 0): ?>
            <div class="card-header border-transparent">
                  <h3 class="card-title">Order Review</h3>

                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                  </div>

          <div class="card-body p-0" style="background-color: #fff">
                <div class="table-responsive">
                  <?php if(count($getPendingTickets) > 0): ?>

                    <table class="table m-0">
                      <thead>
                      <tr>
                         <th>#</th>
                        <th>Ticket id</th>
                        <th>Fullname</th>
                        <th>Subject</th>
                        <th>Status</th>
                      </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $getPendingTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td>#</td>
                        <td><a href="#"><?php echo e($pending->ticket_id); ?></a></td>
                        <td><?php echo e($pending->user->fname); ?> <?php echo e($pending->user->lname); ?></td>
                        <td><?php echo e($pending->subject); ?></td>
                        <td><?php if($pending->status == "open"): ?><span class="badge badge-warning"><?php echo e($pending->status); ?></span> <?php else: ?> <span class="badge badge-success"><?php echo e($pending->status); ?></span> <?php endif; ?></td>
                        
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      
                    <?php endif; ?>
                      </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
              </div>
              <?php else: ?>
              <h2>NO OPEN TICKET</h2>
              <?php endif; ?>
            </div>


          </div>
          
          <div><span style="font-size: 18px;display: none;" id="previous_conversation">Previous Conversations</span><span id="count_previous"></span></div>
          <div id="nav-profile_reply" style="margin-bottom: 10%;border-bottom-width: 1px;margin-top: 10px">
            
          </div>
          <div id="ticket_details" style="display: none;"><h5>Ticket Details</h5></div>
          <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
          
        
          </div>
          
          <div id="nav-profile_details">
            
          </div>
        </div>
        

      
      </div>
    </div>
  </div>
</section>
      </div>

        </div>
        
        
        <!--Tab Navigation Ends -->
        <!--Table Starts-->

        
    </div>


        

    </section>
<script type="text/javascript">


  $(document).ready(function(){
  $tickets = <?php echo json_encode($getPendingTickets, 15, 512) ?>;
  $users = <?php echo json_encode($allusers, 15, 512) ?>;
  $reply = <?php echo json_encode($allreply, 15, 512) ?>;
  
  $("#nav-home-tab").click(function(){
    
        $("#nav-profile").val('');
        $("#nav-profile_details").html('');
        $("#nav-profile_reply").html('')
        $("#count_previous").html('')
        $("#ticket_details").css('display','none');
        $("#previous_conversation").css('display','none');
  })

    $(".nav-item").click(function(){
        $getId = $(this).find('input').attr('value').valueOf();
        $getUserId = $(this).find('input').attr('name').valueOf();
        $("#nav-profile").val('');
        $("#nav-profile_details").html('');
        $("#nav-profile_reply").html('');
        $("#ticket_details").css('display','block');
        $("#previous_conversation").css('display','block');
        var count_previous = 0;
        
        var filterTicketDetails = $tickets.filter(function(el){
          return el.ticket_id == $getId;
        })
        var filterUserDetails = $users.filter(function(el){
          return el.userid == $getUserId;
        })

        var filterUserReply = $reply.filter(function(el){
          return el.ticket_id == $getId;
        })
     
       $.each(filterTicketDetails,function(index,value){
    
    
        $ticket_details = '<div style="width:100%;margin:5"><label>Ticket Subject:</label><div style"background-color:#003300" id="subject">'+value['subject'].toUpperCase()+'</div><label>Message:</label><div style="height:150px;background-color:#f5f5f5;overflow-x:auto">'+value['message']+'</div><label>Reply:</label><Textarea id="reply_message" style="width:100%" rows="5"></Textarea></div><div><input type="checkbox" value="close" id="close_ticket"/><label>Check to Close Ticket</label></div><div><button id="reply">Reply</button></div></div>'
      
      
        $('#nav-profile_details').html($ticket_details);
      });

    $.each(filterUserDetails,function(index,value){
    
    
      $user_details = '<div style="width:100%;margin:5"><label>User('+value['userid']+'):</label><div style"background-color:#003300">'+value['fname'].toUpperCase()+' '+value['lname'].toUpperCase()+'</div></div>'
    
    
    $('#nav-profile').html($user_details);

    })

    $.each(filterUserReply, function(index,value){
      $reply_details = '<div class="row" style="background-color:#fff"><div><img src="<?php echo e(asset("extensions/images/img.jpg")); ?>" style="width:60%;border-radius: 100%"></div><div><label>'+ value['reply_name']+'('+value['role']+')</label><div>'+value['reply_message']+'</div><div>'+value['updated_at']+'</div></div><hr style="width:100%;background-color:#000"/></div>';
      $('#nav-profile_reply').append($reply_details);
      count_previous+=1;
    })

    $("#count_previous").html('('+count_previous+')')
      
      $("#reply").click(function(e){

      

        var reply_message = document.getElementById('reply_message').value
        var subject = document.getElementById('subject').innerHTML;
        var close = "";
        if(reply_message!="" && subject!="" && $getUserId!="" && $getId!=""){
          if ($("input[type=checkbox]").is( 
                      ":checked")) { 
                        close="close"
                    } 
             $.ajax({
             url:'<?php echo e(route("reply_ticket")); ?>',
             type:'post',
             headers: { 'X-CSRF-TOKEN': $('input[name=_token]').val() },
             beforeSend:function(){
              
              $("#reply").attr('disabled',false);
              
             },
             data:{
                    userid:$getUserId,
                    reply_message:reply_message,
                    subject:subject,
                    ticket_id:$getId,
                    close:close,
                    "_token": "<?php echo e(csrf_token()); ?>"        
                  },
            success:function(data){
                   console.log('Data',data)
                   if(data=="Reply was successfully saved"){
                    window.location='<?php echo e(route("index")); ?>';
                   }
               
             },
            error:function(object, status, e){
                
                    
                    console.log(e);
            }
        })
         
        }
        else{
          alert('All Fileds are Required');
        }
        

    

        

         

    })

      
    })


    


  })
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('wabloan.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\customer_care.blade.php ENDPATH**/ ?>