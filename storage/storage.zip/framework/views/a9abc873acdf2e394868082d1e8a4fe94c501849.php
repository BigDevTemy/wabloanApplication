<!DOCTYPE html>
<html>
<head>
	<title>Wabloan</title>
</head>
<body>
	<div style="width: 100%;margin-top: 50%;color:#000" align="center">
		
		<span>WELCOME TO WABLOAN LENDING ENTERPRISE..</span>

	</div>
</body>
</html><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\new_welcome.blade.php ENDPATH**/ ?>