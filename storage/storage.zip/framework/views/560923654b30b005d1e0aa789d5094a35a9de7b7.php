<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html>
<head>
	<title>RegisterAdminUser Page</title>
   <!--Made with love by Mutiullah Samim -->
   <link rel="stylesheet" href="<?php echo e(asset('loginnew.css')); ?>">
	<!--Bootsrap 4 CDN-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
    <!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

	<!--Custom styles-->
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<div class="container">
	<div class="row" style="width: 100%;height: 100%">
					


					<div class="col-md-12">
						<div class="d-flex justify-content-center h-90" style="margin-top:10%">
		<div class="card" style="width: 50%;height: 100%;border-radius: 10">
			<div class="card-header">
				<h3 style="font-size: 16px">WabLoan Admin Registration</h3>
				
			</div>
			<div class="card-body">
				
				<form method="POST" action="<?php echo e(route('admin.save_registration')); ?>">
					<?php echo csrf_field(); ?>

					<?php if($errors->any()): ?>
                        <div class="alert alert-info" style="width: 100%;font-size: 14">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

					<div class="input-group form-group">
						<div class="input-group-prepend" style="background-color: #bad555">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input type="text" class="form-control" placeholder="Firstname" name="firstname" value="<?php echo e(old('firstname')); ?>">
						
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend" style="background-color: #bad555">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input type="text" class="form-control" placeholder="Lastname" name="lastname" value="<?php echo e(old('lastname')); ?>">
						
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend" style="background-color: #bad555">
							<span class="input-group-text"><i class="fas fa-at"></i></span>
						</div>
						<input type="email" class="form-control" placeholder="EmailAddress" name="email" value="<?php echo e(old('email')); ?>">
						
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend" style="background-color: #bad555">
							<span class="input-group-text"><i class="fas fa-phone"></i></span>
						</div>
						<input type="text" class="form-control" placeholder="Phonenumber" name="phonenumber" value="<?php echo e(old('phonenumber')); ?>">
						
					</div>
					
					<div class="input-group form-group">
						<div class="input-group-prepend" style="background-color: #bad555">
							<span class="input-group-text"><i class="fas fa-key"></i></span>
						</div>
						<input type="password" class="form-control" placeholder="Password" name="password" value="<?php echo e(old('password')); ?>">
					</div>
					
					<div class="form-group">
						<input type="submit" value="Login" class="btn float-right login_btn" style="background-color: #bad555;color:#fff">
					</div>
				</form>
			</div>
			
		</div>
	</div>

					</div>

	</div>
	
</div>
</body>
</html><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\registerAdminUser.blade.php ENDPATH**/ ?>