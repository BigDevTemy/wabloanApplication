

<?php $__env->startSection('content'); ?>
	<section class="content">
		<div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <div class="m-0 text-dark" style="font-size: 16px;font-weight: bold">Change Password</div>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
              <li class="breadcrumb-item active">ChangePassword</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
		<div class="card">
		    <div class="card-body register-card-body">
		      <p class="login-box-msg"><h5>Change Password</h5></p>
		      <?php if($errors->any()): ?>
                <div class="alert alert-info" style="width: 100%;font-size: 14">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
              <?php endif; ?>
		      <form action="<?php echo e(route('post_changepassword')); ?>" method="post">
		      	<?php echo csrf_field(); ?>
					
		        <div class="input-group mb-3">
		          <input type="text" class="form-control"  name="oldpassword" placeholder="Old Password" value="<?php echo e(old('oldpassword')); ?>">
		          <div class="input-group-append">
		            <div class="input-group-text">
		              <span class="fas fa-key"></span>
		            </div>
		          </div>
		        </div>
		        <div class="input-group mb-3">
		          <input type="text" class="form-control" name="newpassword" placeholder="New Password" value="<?php echo e(old('newpassword')); ?>">
		          <div class="input-group-append">
		            <div class="input-group-text">
		              <span class="fas fa-key"></span>
		            </div>
		          </div>
		        </div>

		        <div class="input-group mb-3">
		          <input type="text" class="form-control" name="confirmnewpassword" placeholder="Confirm New Password" value="<?php echo e(old('confirmnewpassword')); ?>">
		          <div class="input-group-append">
		            <div class="input-group-text">
		              <span class="fas fa-key"></span>
		            </div>
		          </div>
		        </div>
		        
		       
		        
		        
		        <div class="row">
		          <div class="col-12">
		            <button type="submit" class="btn btn-success btn-block" style="font-size: 14px">Change Password</button>
		          <!-- /.col -->
		           <!-- /.col -->
		        </div>
		    	</div>
		      </form>

		      

		     
		    </div>
		    <!-- /.form-box -->
		  </div>
		
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wabloan.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\changepassword.blade.php ENDPATH**/ ?>