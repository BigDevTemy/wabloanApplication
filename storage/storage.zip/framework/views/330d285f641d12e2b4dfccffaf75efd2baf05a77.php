<!DOCTYPE html>
<html>
<head>
	<title>Wabloan|Terms and Condition</title>
	<?php echo $__env->make('wabloan.includes.toplink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div class="row">
	<div class="col-lg-12" align="center">
		<h3>TERMS AND CONDITIONS TO BORROWERS</h3>
		<div align="left" style="width: 90%">
		<p>
			These Terms and Conditions apply to and regulate the provision of credit facilities by Wabloan to the Borrower herein. These Terms and Conditions constitute the Lender’s offer and sets out the terms governing this Agreement
		</p>
		<p>
			Wabloan is an open-end credit plan offered by the Lender and by accepting, an account is set up with Wabloan and you agree that you have read the Terms and Conditions. You authorize the Lender to review your credit report and you understand that this account is subject to transaction fees and default fees and is governed by the Laws of the Federal Republic of Nigeria.
		</p>	
		<p>You will be asked to provide information (such as your date of birth and your Bank Verification Number), when you apply for a Wabloan. This information is used for verification purposes.</p>
		<h5>HOW TO USE WAB LENDING COMPANY LIMITED ACCOUNT</h5>
		<p>
			This is an open-end credit account where you access direct loan or credit facility using Wabloan, while you repay the loan or credit facility on a future date via cash transfer or electronic repayment from your debit/credit card on the Payment Due Date at a flat interest on the loan of up to 1% daily.
		</p>
		<p>Party A: Wab Lending Company Limited, account name of the platform: [Wab Loan].</p>
		<p>Party B:[user's name],platform account name: [user's mobile number],id number:[ ],address:[ ],company:[user's company]</p>
		<div style="float: left;font-family: candara;font-weight:bold;font-size: 16px;width: 100%" >	DEFINITION</div>
		<p>In this agreement, the terms: “Party “B”, “You”, “your”, “Customer”, and “Borrower” mean the person who applied for this Account and agrees to this Agreement while “Party “A”, “We”, “us”, “our” and “Lender” shall mean Wabloan, and following an assignment, any person, company or bank to whom the rights and/or obligations of the Lender have been assigned</p>
		<ul>
			<li>“Account” means the Borrower’s account with the Lender</li>
			<li>“Disbursement Date” means the date the Lender actually advanced the loan to the Borrower</li>
			<li>“Payment Due Date” means a maximum of 5, 10 or 15 days depending on the tenure chosen, after 			the loan has been given</li>
			<li>“Credit Limit” means the maximum credit available to the Borrower on opening the account with the Lender</li>
			<li>“Loan” means the amount advanced to the Borrower by the Lender, which shall be no less than N5,000.00 (Five Thousand Naira only)</li>

		</ul>
		<div style="float: left;font-family: candara;font-weight:bold;font-size: 16px;width: 100%" > CUSTOMER CONSENT</div>
		<ul>
			<li>By ticking the “I agree to the Terms and Conditions”, on the application form, which you hereby adopt as your electronic signature, you consent and agree that:</li>
			<li>We can provide materials and other information about your legal rights and duties to you electronically.</li>
			<li>We are authorized to share, receive and use data/information collected from your transaction with other affiliated Third parties.</li>
		</ul>
		<div style="float: left;font-family: candara;font-weight:bold;font-size: 16px;width: 100%" >I. BORROW</div>
		<ul>
			<li><p>
				1. Party “B” shall borrow money from party “A” for personal purchase of commodities or related services, and promise to repay capital and interest to party “A” on a monthly basis. Party “B” shall not use the loan item for any purpose other than the borrowing purpose.
				<table style="width:70%;border:1px solid #000;margin-top: 10px;font-size: 14px;font-family: candara" border="1px">
					<tr>
						<td>
							Loan Amount
						</td>
						<td>
							&#8358;: (Principal Amount) 
						</td>
					</tr>
					<tr>
						<td>
							Date of Loan 
						</td>
						<td>
							(Lending) Disbursement Date 
						</td>
					</tr>

					<tr>
						<td>
							Days 
						</td>
						<td>
							loan period (5,10,15days) 
						</td>
					</tr>
					<tr>
						<td>
							To borrow 
						</td>
						<td>
							The starting date to due date 
						</td>
					</tr>
					<tr>
						<td>
							The due date of repayment 
						</td>
						<td>
							Due date (24-11-2020)
						</td>
					</tr>
					<tr>
						<td>
							Interest
						</td>
						<td>
							&#8358;: 15% -45% of every borrowed loan
						</td>
					</tr>
					<tr>
						<td>
							Repayment amount
						</td>
						<td>
							&#8358;: total repayment
						</td>
					</tr>
				</table>
			</p>
			</li>
			<li><p>2. The borrowing purpose hereunder shall be the borrowing purpose specified in the loan schedule, and party “B” shall not use the borrowing term for any purpose other than the borrowing purpose.</p></li>
			<li><p>
				3. Loan: party “A” shall, within 24hrs upon signing and taking effect of this agreement, pay the loan to party “B's” following bank account (herein after referred to as "party “B” account") as authorized by party “A”: Username:[user's name];Mobile number: [user card number]; Party “A” actually pays the loan principal specified in the first paragraph to party b's account in accordance with the provisions of this paragraph, and party a's loan obligation under this agreement is fulfilled. The date of party a's actual payment to party b's account is the loan date (hereinafter referred to as the "actual loan date"). If the actual loan date is inconsistent with the loan date specified in the loan schedule, the actual loan date shall prevail, and the final maturity date in the loan schedule shall be adjusted accordingly according to the actual loan date. For the actual loan date and the actual final maturity date, party b can inquire through party a's platform.</p>
			</li>
		
			
		</ul>
		<div style="float: left;font-family: candara;font-weight:bold;font-size: 16px;width: 100%" >II. THE REPAYMENT</div>
		<ul>
			<li><p>
				1. Party B shall return the principal and pay the interest to Party A in accordance with the provisions hereof; In case of overdue repayment, Party B shall pay Party A the overdue liquidated damages and overdue fine as agreed herein. The aforementioned amount payable by Party B shall be collectively referred to as "account payable by Party B".
			</p></li>
			<li>
				<p>
					2. Party B shall make repayment in the following ways: Party B irrevocably authorizes Party A or the third party designated by Party A to deduct the corresponding amount from the account of Party B specified in article 1, paragraph 3 above on the repayment day and transfers the amount to the account approved by Party A for the repayment of the current payable amount payable to Party B to Party A.
				</p>
			</li>
			<li><p>
				3.	Party B shall return all amounts payable to Party A on or before the due date. The date of maturity repayment refers to the date of repayment agreed in the schedule of this loan, and the amount of repayment principal and interest is the total amount of repayment principal and interest agreed in the schedule of loan.
				</p>
			</li>
			<li><p>
				4.	The term of authorization of Party B to Party A and/or the third party designated by Party A in accordance with the provisions of this agreement shall start from the effective date of this agreement and continue until Party B pays off all the money that it shall return and pay under the tripartite agreement. Party B shall not revoke all or part of its authorization to Party A and/or the third party designated by Party A under this authorization within the authorization period..
				</p>
			</li>
			<li>
				<p>5. Date of return: the date of successful repayment of the current payment shall be the date on which the corresponding amount reaches Party A's account or Party A's bank account</p>
			</li>
		</ul>
		<div>
		<div style="float: left;font-family: candara;font-weight:bold;font-size: 16px;width: 100%" >III OVERDUE REPAYMENT</div>
		<ul>
			<li><p>1.	If Party B fails to pay the due amount before 24:00 of each due date, it shall be deemed as overdue.</p></li>
			<li><p>2. If Party B delays in each term, it shall pay the overdue penalty and late fee (the aforementioned amount shall be referred to as "overdue payment") in addition to the payable principal and interest.</p></li>
			<li><p>If the repayment amount of Party B is insufficient to pay all overdue payments, Party B shall pay in the following order: 
				<ul>
				<ol>I. Overdue liquidated damages </ol>
 				<ol>II. Interest</ol>
				<ol>III. The principal.</ol>
				</ul>
			</p></li>
			<li><p>4. Party B may log into the account of Party A to check the interest due on the principal and the overdue payment late fee and overdue penalty.</p></li>
			<li><p>5. In case of any overdue payment, Party B shall, in accordance with the provisions of paragraph 2 of this article, pay overdue fine, overdue penalty, interest and principal to Party A shall not be refunded.</p></li>
			<li><p>6. In case of overdue repayment, Party B shall promptly perform the repayment obligations. Party A shall have the right to, or authorize Party A or Party A's legal trustee to, remind and urge Party B to fulfill the repayment obligations by phone, SMS, email or other legal means. Party B has fully read and understood the meaning of this provision and fully agrees.</p></li>
			<li><p>7. Party A may at any time to Party B the creditor's rights (including but not limited to loan principal and interest, overdue penalty due to breach of contract, payment is overdue fine for delaying payment, etc., the same below) transfer to Party A or any others, and authorization of Party A or Party A specified in its own name to the rest of the creditor's rights transfer notice to Party B, on the basis of this agreement by Party A to Party B send the notice of assignment of creditor's rights shall be regarded as issued by Party A, Party B acceptance notice of any such transfer of creditor's rights and send the notice of assignment of creditor's rights by Party A have the same legal effect, Party B will not related to the effectiveness of the notice of any such transfer of creditor's rights and creditor's rights transfer effectiveness put forward any objection. After Party A or other person obtains the creditor's rights against Party B, it can be transferred according to law. All expenses incurred by the creditor as a result of Party B's late repayment, including but not limited to attorney's fee, investigation fee, collection fee and preservation fee, etc. shall be borne by Party B.</p></li>
		</ul>
		<div style="float: left;font-family: candara;font-weight:bold;font-size: 16px;width: 100%" >IV.	REPRESENTATIONS AND WARRANTIES</div>
		<ul>
			<li>
				<p> 1. Party B undertakes and guarantees that the information provided by it is true, complete and valid. If any personal information of Party B changes, Party B shall notify Party A within 3 working days from the date of the change. If Party B fails to inform the change in time, any consequences, losses and expenses caused by Party B shall be borne by Party B. To bear</p>
			</li>
			<li>
				<p> 1. Party B undertakes and guarantees that the information provided by it is true, complete and valid. If any personal information of Party B changes, Party B shall notify Party A within 3 working days from the date of the change. If Party B fails to inform the change in time, any consequences, losses and expenses caused by Party B shall be borne by Party B. To bear</p>
			</li>
			<li>
				<p> 1. Party B undertakes and guarantees that the information provided by it is true, complete and valid. If any personal information of Party B changes, Party B shall notify Party A within 3 working days from the date of the change. If Party B fails to inform the change in time, any consequences, losses and expenses caused by Party B shall be borne by Party B. To bear</p>
			</li>
			<li>
				<p> 1. Party B undertakes and guarantees that the information provided by it is true, complete and valid. If any personal information of Party B changes, Party B shall notify Party A within 3 working days from the date of the change. If Party B fails to inform the change in time, any consequences, losses and expenses caused by Party B shall be borne by Party B. To bear</p>
			</li>
			<li>
				<p> 1. Party B undertakes and guarantees that the information provided by it is true, complete and valid. If any personal information of Party B changes, Party B shall notify Party A within 3 working days from the date of the change. If Party B fails to inform the change in time, any consequences, losses and expenses caused by Party B shall be borne by Party B. To bear</p>
			</li>
		</ul>
		<div style="float: left;font-family: candara;font-weight:bold;font-size: 16px;width: 100%" >V. DEFAULT</div>
		<p>Any occurrence of any one or more of the following circumstances shall be deemed as Party B's breach of contract:</p>
		<ul>
			<li><p>
				(1) Party B provides false information or intentionally conceals important facts, affecting Party A and Party A's ability to assess Party B's credit and repayment ability;
			</p></li>
				<ul><li><p>
					(2) Party B violates any of its obligations, promises or guarantees under this Agreement;
				</p></li>
				<li><p>
					(3) Party B arbitrarily changes the purpose of the loan as agreed in this agreement;
				</p></li>
				<li><p>
					(4) Any property of Party B is subject to confiscation, requisition, seizure, seizure, freezing, and other adverse events that may affect its ability to perform, and fails to provide effective remedies in a timely manner;
				</p></li>
				<li><p>
					(5) Party B's financial situation has adverse changes affecting its ability to perform, and effective remedies cannot be provided in a timely manner.
				</p></li>
				</ul>
			<li><p>2. If Party B defaults or Party A reasonably judge Party B's possible breach of contract, Party A (commission Party A and its legal trustee) has the right to take one or more of the following remedies:</p></li>
			<ul>
				<li>
					<p>(1) Declare that all the borrowed loans have expired in advance, and Party B shall immediately repay all the payables in accordance with the provisions of this agreement regarding early repayment, and bear the corresponding liability for breach of contract;</p>
				</li>
				<li>
					<p>(2) Immediately terminate the contents of the loan related part of this agreement;</p>
				</li>
				<li>
					<p>(3) Adopt laws, regulations and other remedies agreed in this agreement.</p>
				</li>
				
			</ul>
			<li><p>3. If Party B defaults, it shall compensate Party A and/or Party A for the losses suffered, including the resulting legal fees, investigation fees, reminder fees, etc.; and, in the event of Party B’s breach of contract</p>
			</li>

		</ul>
		<div style="float: left;font-family: candara;font-weight:bold;font-size: 16px;width: 100%" >VI. PRIVACY POLICY</div>
		<ul>
			<li><p>1. After the signing of this Agreement, the parties to this Agreement shall bear the following confidentiality obligations unless otherwise agreed in advance by the parties:</p>
			</li>
			<ul>
				<li>
					<p>(1) Neither party shall disclose this Agreement and any matters under this Agreement and any documents, materials or information relating to such matters to parties other than the parties to this Agreement (other than Party A and its trusted third party service providers/partners). ("Confidential Information");</p>
				</li>
				<li>
					<p>(2) Either party may only use the Confidential Information and its contents for the purposes of this Agreement and shall not be used for any other purpose. The terms of this paragraph do not apply to the following confidential information:</p>
					<ul>
						<li><p>A. When it is obtained from the disclosing party, it is already public;</p></li>
						<li><p>B. The recipient has been informed before obtaining it from the disclosing party;</p></li>
						<li><p>C. Obtained from a third party that has legitimate authority and is not subject to confidentiality obligations;</p></li>
						<li><p>D. Developed solely on the basis of information disclosed or provided by the disclosing party.</p></li>
					</ul>
				</li>
				
			</ul>
			<li>
					<p>2. Disclosure of confidential information for the following reasons is not subject to the restrictions of the preceding paragraph:</p>
					<ul>
						<li><p>
							(1) Disclosure to accountants, lawyers, and consulting companies hired by the parties to this agreement;
							</p>
						</li>
						<li><p>
							(2) Disclosure in accordance with the mandatory provisions of applicable laws and regulations;
							</p>
						</li>
						<li><p>
							(3) Disclosure to the approval authority and/or authority in accordance with other regulations to be followed;
							</p>
						</li>
						<li>
							<p>(4) Disclosed to the relevant third party for the purposes of this Agreement.</p>
						</li>

					</ul>
			</li>
		</ul>
		<div style="float: left;font-family: candara;font-weight:bold;font-size: 16px;width: 100%" >VII. PRIVACY POLICY</div>
		<ul>
			<li><p>
				1. The notices and/or documents made by any party to this Agreement in accordance with the terms of this Agreement shall be issued in writing (including but not limited to e-mail, SMS, Party A platform information announcement, station letter, etc.). All notices issued by this Agreement are legal and valid notices.
			</p></li>
			<li><p>
				2. If any party to this Agreement changes its contact person or contact address or email address, it shall, as soon as possible, notify the parties in writing within 3 working days from the date of the change of relevant information.
			</p></li>
			<li><p>
				3. The parties hereby confirm that if the parties have disputes arising from the signing and performance of this contract, the above address will also serve as a valid delivery address for the relevant notices and instruments as dispute resolution bodies (including courts and arbitral institutions).
			</p></li>
		</ul>
		<div style="float: left;font-family: candara;font-weight:bold;font-size: 16px;width: 100%" >VIII. APPLICATION AND JURISDICTION OF THE LAW</div>
		<p>
			The signing, performance, termination and interpretation of this Agreement shall be governed by the laws of the Federal Republic of Nigeria. The parties agree that all disputes arising out of or in connection with this Agreement shall be settled through negotiation; if the negotiations fail to reach an agreement, they shall submit the litigation in the Court where the agreement is signed.
		</p>
		<div style="float: left;font-family: candara;font-weight:bold;font-size: 16px;width: 100%" >IX.	OTHER</div>
		<ul>
			<li>
				<p>1. Each Party Authorizes Party A to provide all information provided by Party B to Party A at the reasonable request of either party. Party B is also obliged to provide Party A with any information or materials related to Party B at any time upon request.</p>
			</li>

			<li>
				<p>2. Party A reserve the right to disclose the relevant information of Party B's default and breach of trust on Party A's platform or other media.</p>
			</li>

			<li>
				<p>3. A copy of the facsimile, photocopy, scanned copy, or other electronic copy of this Agreement is equivalent to the legal effect of the original.</p>
			</li>

			<li>
				<p>4. All parties agree that the signing, entry into force and performance of this Agreement are based on the premise of not violating Nigeria laws and regulations. If any one or more of the Agreements violates applicable laws and regulations, the Article will be deemed invalid. However, this invalid clause does not affect the legal effect of other provisions of this Agreement.</p>
			</li>
			<li>
				<p>5. Party B confirms that it has fully read and understood the terms of this agreement. After signing this agreement, Party B will have no objection to this agreement, and Party B will unconditionally agree to perform in accordance with this agreement.</p>
			</li>



		</ul>
		</div>
		</div>

		
	</div>
	

</div>
</body>
</html><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\terms_n_condition.blade.php ENDPATH**/ ?>