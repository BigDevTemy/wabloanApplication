
<?php $__env->startSection('content'); ?>
<style type="text/css">
	
	/* Tabs*/
section {
    padding: 5px ;
}

section .section-title {
    text-align: center;
    color: #007b5e;
    margin-bottom: 20px;
    text-transform: uppercase;
}
#tabs{
	background-color: #f3f3f3;
    color: #003300;
    font-family: 'candara';
    font-size: 14px;
}
#tabs h6.section-title{
    color: #fff;
}

#tabs .nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link.active {
    color: #000000;
    background-color: transparent;
    border-color: transparent transparent #000000;
    border-bottom: 4px solid !important;
    font-size: 12px;

    font-weight: bold;
}
#tabs .nav-tabs .nav-link {
    border: 1px solid transparent;
    border-top-left-radius: .25rem;
    border-top-right-radius: .25rem;
    color: #000;
    font-size: 12px;
    font-family: 'candara';
}
</style>
<section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fa-cog"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Awaiting Loan Review</span>
                <span class="info-box-number">
                  <?php echo e(count($all_pending_request_loan)); ?>

                  <small></small>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          
         
        </div>
        <!-- /.row -->

        <!--Tab Navigation -->
        <div class="row">
        	<section id="tabs">
	<div class="container">
		
		<div class="row">
			<div class="col-xs-12 ">
				<nav>
					<?php if(count($all_pending_request_loan) > 0): ?>
					<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
						<a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Review Order</a>
						<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Assignee</a>
						<a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Action</a>
						
					</div>
				</nav>
				
				
				<form method="POST" action="<?php echo e(route('assignReviewJob')); ?>">
				<div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
					
						<?php echo csrf_field(); ?>
					<div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
					<?php if($errors->any()): ?>
                                          <div class="alert alert-info" style="width: 100%;font-size: 14">
                                                <ul>
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($error); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
					
					<div class="card">
						<div class="card-header border-transparent">
	                <h3 class="card-title">Order Review</h3>

	                <div class="card-tools">
	                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
	                    <i class="fas fa-minus"></i>
	                  </button>
	                  <button type="button" class="btn btn-tool" data-card-widget="remove">
	                    <i class="fas fa-times"></i>
	                  </button>
	                </div>
              		</div>

					<div class="card-body p-0" style="background-color: #fff">
                <div class="table-responsive">
                	<?php if(!empty($all_pending_request_loan)): ?>

	                  <table class="table m-0">
	                    <thead>
	                    <tr>
	                       <th>#</th>
	                      <th>Loan id</th>
	                      <th>Fullname</th>
	                      <th>Loan Amount</th>
	                      <th>Loan Interest</th>
	                      <th>Loan Tenure</th>
	                      <th>Loan Total</th>
	                      <th>Review Status</th>
	                    </tr>
	                    </thead>
	                    <tbody>
						<?php $__currentLoopData = $all_pending_request_loan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    <tr>
	                    	<td><input type="checkbox" name="checkbox[]" value="<?php echo e($pending->id); ?>"></td>
	                      <td><a href="#"><?php echo e($pending->loanID); ?></a></td>
	                      <td><?php echo e($pending->user->fname); ?> <?php echo e($pending->user->lname); ?></td>
	                      <td><?php echo e($pending->loan_amount); ?></td>
	                      <td><?php echo e($pending->loan_interest); ?></td>
	                      <td><?php echo e($pending->loan_tenure); ?></td>
	                      <td><?php echo e($pending->loan_total); ?></td>
	                      <td><?php if($pending->review_status == "pending"): ?><span class="badge badge-warning">pending review</span> <?php else: ?> <span class="badge badge-success"><?php echo e($pending->review_status); ?></span> <?php endif; ?></td>
	                      
	                    </tr>
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                    
	                    
	                  <?php endif; ?>
	                    </tbody>
	                  </table>
                </div>
                <!-- /.table-responsive -->
              </div>
          	</div>


					</div>
					<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
					
					<div class="card">
						<div class="card-header border-transparent">
	                		
	                		<div style="width: 100vh" class="card-title"><h3 >Assign Users</h3></div>

              			</div>

              			

					<div class="card-body p-0" style="background-color: #fff">
						<?php if(!empty($review_members)): ?>

							<div class="input-group mb-3">
					          	<select class="form-control" name="role_userid">
						          	<option value="" selected>Pick User's Role</option>
						          	<?php $__currentLoopData = $review_members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($member->userid); ?>"><?php echo e($member->fname); ?> <?php echo e($member->lname); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					          	</select>
		          
		        			</div>
		        		<?php endif; ?>

					</div>
				
					</div>


					</div>
					<div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab"> 
		          		<div>
		          			<div style="width: 100vh" class="card-title"><h3 >Action</h3></div>
		            		<button type="submit" class="btn btn-success btn-block">Assign</button>
		          
				        </div>
				    	
					</div>
					
				</div>
				<form>
				
				<?php else: ?>
				<div class="alert alert-info" style="width: 100vh;font-size: 16">
					
					NO AWAITING ORDER
				</div>
				<?php endif; ?>
			
			</div>
		</div>
	</div>
</section>
   		</div>

        </div>
        
        
        <!--Tab Navigation Ends -->
        <!--Table Starts-->

        
    </div>


        

    </section>
<script type="text/javascript">
	function openCity(cityName) {
  var i;
  var x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  document.getElementById(cityName).style.display = "block";
}

</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('wabloan.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\awaiting_loanrequest.blade.php ENDPATH**/ ?>