
<?php $__env->startSection('content'); ?>

<section class="content">
  <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <div class="m-0 text-dark" style="font-size: 16px;font-weight: bold">My Order</div>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fa-cog"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Assigned Order Review</span>
                <span class="info-box-number">
                  <?php echo e(count($get_all_assigned)); ?>

                  <small></small>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          
         
        </div>
        <!-- /.row -->

        <!--Tab Navigation -->
        <div class="row">
        	<?php if($errors->any()): ?>
                  <div class="alert alert-info" style="width: 100%;font-size: 14">
                        <ul>
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                   </div>
            <?php endif; ?>
        	<?php if(count($get_all_assigned) > 0): ?>
        	<div class="col-md-12">
                            <div class="main-card mb-3 card">
                                <table id="all_assigned_order" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Loan ID</th>
                                            <th>Loan Amount</th>
                                            <th>Loan Interest</th>
                                            <th>Loan Tenure</th>
                                            <th>Loan Total</th>
                                            <th>AssignedTo</th>
                                            <th>Review_status</th>
                                            <th>Action</th>

                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php if(!empty($get_all_assigned)): ?>
                                            <?php $__currentLoopData = $get_all_assigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assigned): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                	<input type="hidden" id="<?php echo e($assigned->id); ?>">
                                                    <td><?php echo e($assigned->id); ?></td>
                                                    <td><?php echo e($assigned->loanID); ?></td>
                                                    <td><?php echo e($assigned->loan_amount); ?></td>
                                                    <td><?php echo e($assigned->loan_interest); ?></td>
                                                    <td><?php echo e($assigned->loan_tenure); ?></td>
                                                    <td><?php echo e($assigned->loan_total); ?></td>
                                                    <td><?php echo e($assigned->user_assign->fname); ?> <?php echo e($assigned->user_assign->lname); ?></td>
                                                    <td>
                                                    	<?php echo e($assigned->review_status); ?>

                                                    </td>
                                                    <td><button class="btn btn-success btn-block" id="action">
                                                    	<div class="edit_brand" style="cursor: pointer" data-toggle="modal" data-target="#reassign"><input type="hidden"  id="<?php echo e($assigned->id); ?>"><u>Edit</u></div>
                                                    </td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        
                                    </tbody>
                                    
                                </table>
                            </div>
            </div>
            <?php endif; ?>
   		</div>

        </div>
        
       

    </section>
<script type="text/javascript">
	function openCity(cityName) {
  var i;
  var x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  document.getElementById(cityName).style.display = "block";
}

</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('wabloan.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\all_assigned_order.blade.php ENDPATH**/ ?>