<!DOCTYPE html>
<html>
<head>
	<title>WabLan Onboarding Message</title>
</head>
<body>
   
<center>
<h2 style="padding: 23px;background: #b3deb8a1;border-bottom: 6px green solid;">
	<a href="https://wabloan.com">Visit Our Website : wabloan.com</a>
</h2>
</center>
  
<p>Hi, Sir</p>
<p>Trust this mail meets you well?<br/>
Welcome to Wabloan Lending paltform, its our desire to assist withwith your loan request as at when need , all to meet your need.

This is a notification message to welcome you to the community.

Feel free to raise a ticket on from you app platform or via email.
</p>
  
<strong>Gratitude. :)</strong>

<p>
	Odewumi Temiloluwa Vincent<br/>
	Team Technical Support.

</p>
  
</body>
</html><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\email\onboarding.blade.php ENDPATH**/ ?>