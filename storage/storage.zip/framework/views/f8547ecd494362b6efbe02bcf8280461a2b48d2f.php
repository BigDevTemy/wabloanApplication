
  <script type="text/javascript" src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('newjs/jquery-3.5.1.js')); ?>"></script>
<nav class="main-header navbar navbar-expand navbar-white navbar-light" style="background-color: #282C35;">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars" style="color: #cccccc"></i></a>
      </li>
      
    </ul>

    <!-- SEARCH FORM 
    <form class="form-inline ml-3">
      <div class="input-group input-group-sm">
        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            <i class="fas fa-search" style="color: #fff"></i>
          </button>
        </div>
      </div>
    </form>
    -->


    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-bell" style="color: #cccccc;width: 20px"></i>
          <span class="badge badge-warning navbar-badge" style="color: #fff;font-size: 8px" id="new_order">0</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header">Alert Notifications</span>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-envelope mr-2"></i><span id="append_new_order"></span>
            
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
        </div>
      </li>
      

    <!--
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
         
          <?php if(Auth::user()->imageurl != ""): ?>
           
           <?php else: ?>
            <img src="<?php echo e(asset('extensions/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" style="width:8%" alt="User Image">
           <?php endif; ?>

           <span style="color: #fff;font-size:12px"><?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?> <?php $__currentLoopData = Auth::user()->Roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              (<?php echo e($role->name); ?>)
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span>
          }
           
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          
          <a href="<?php echo e(route('logout')); ?>" class="dropdown-item">
            
            <div class="media">
              <img src="<?php echo e(asset('extensions/dist/img/user1-128x128.jpg')); ?>" alt="User Avatar" class="img-size-50 mr-3 img-circle">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  <?php echo e(Auth::user()->fname); ?>

                  <span class="float-right text-sm text-danger"><i class="fas fa-star" style="color: #fff"></i></span>
                </h3>
                <p class="text-sm">Logout</p>
                
              </div>
            </div>
            
          </a>

          <div class="dropdown-divider"></div>
           
        </div>
      </li>

    -->

      <li class="nav-item" style="color: #cccccc;margin: 5px;"><i class="fas fa-user-alt" style="margin-right: 3px"></i>Personal Data</li>
      <li class="nav-item" style="color: #cccccc;margin: 5px;"><a href="<?php echo e(route('changepassword')); ?>" style="color: #cccccc"><i class="fas fa-lock" style="margin-right: 3px"></i>Change Password</a></li>
      <li class="nav-item" style="color: #cccccc;margin: 5px;"><a href="<?php echo e(route('logout')); ?>" style="color: #cccccc"><i class="fas fa-power-off" style="margin-right: 3px"></i>Logout</a></li>

    </ul>
  </nav>
  <script type="text/javascript">
    $(document).ready(function(){

      var review_order_update = function(){
        $.ajax({
          url:'<?php echo e(route("ajax_pending")); ?>',
          type:'get',
          headers: { 'X-CSRF-TOKEN': $('input[name=_token]').val() },
          data:{
              
              "_token": "<?php echo e(csrf_token()); ?>"        
              },
          success:function(data){
            
              document.getElementById('new_order').innerHTML=data['count'];
              $("#append_new_order").html(data['count']+' order for review')
              
          },
          error:function(object, status, e){
            console.log(e)
            
                                
          }

        })
      }
      var interval = 1000 * 5 ;

      setInterval(review_order_update, interval);

      $("#append_new_order").click(function(){
        var content = document.getElementById('append_new_order').innerHTML;
        
        if(content == "0 order for review"){

        }
        else{
          window.location='<?php echo e(route("index")); ?>'
        }
      })

    })


  </script><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\includes\header.blade.php ENDPATH**/ ?>