
<table style="width:100%">
	<tr>
		<td style="width: 50%">
			Dear <strong><?php echo e($data[1]); ?></strong>

			<p style="font-family:'candara'">Thank you for choosing WabLoan Enterprise.<br/>

				Kindly find below password credential for your attention.

				<p style="font-family:'candara'">Passord:<?php echo e($data[0]); ?></p>

				<strong>Please Ensure you change the said password upon logging into your profile dashboard.</strong>

			</p>
			<p style="color: #00688B">Welcome ONBOARD!</p>

			<p><div style="margin-top:10%;width:100%;background-color: #dedede;font-family: 'candara'" align="center">
				Please Contact us at<br/>
				<a href="support@wabloan.com">support@wabloan.com</a> or by phone on<br/>
				09077766654
			</div></p>
			<p style="font-family: 'candara'">Yours Truly, <strong>Admin</strong></p>
			<p style="font-family: 'candara'">website:<a href="https://www.wabloan.com" style="color: #bad555">https://www.wabloan.com</a></p>

		</td>
		<td style="width: 50%">
			<div style="width: 100%;"  align="center">
				<img src="https://6d0ea0c55c5f.ngrok.io/wabloan_selfie/logo_wabloan.png" style="width:25%" />	
			</div>
			
		</td>
	</tr>
</table>
<?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\email\passwordnotification.blade.php ENDPATH**/ ?>