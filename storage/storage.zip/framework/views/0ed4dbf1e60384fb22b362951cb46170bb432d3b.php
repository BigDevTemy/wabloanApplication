

<?php $__env->startSection('content'); ?>
	<section class="content">
		<div class="content-header">
      	<div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <div class="m-0 text-dark" style="font-size: 16px;font-weight: bold">Create Backend Staff</div>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Create Staff</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
		<div class="card">
		    <div class="card-body register-card-body">
		      <p class="login-box-msg">Create Staff User</p>
		      <?php if($errors->any()): ?>
                                          <div class="alert alert-info" style="width: 100%;font-size: 14">
                                                <ul>
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($error); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
		      <form action="<?php echo e(route('admin.create_staff_profile')); ?>" method="post">
		      	<?php echo csrf_field(); ?>
					
		        <div class="input-group mb-3">
		          <input type="text" class="form-control"  name="fname" placeholder="First Name" value="<?php echo e(old('firstname')); ?>" style="font-family: candara">
		          <div class="input-group-append">
		            <div class="input-group-text">
		              <span class="fas fa-user"></span>
		            </div>
		          </div>
		        </div>
		        <div class="input-group mb-3">
		          <input type="text" class="form-control" name="lastname" placeholder="Last Name" value="<?php echo e(old('lastname')); ?>" style="font-family: candara">
		          <div class="input-group-append">
		            <div class="input-group-text">
		              <span class="fas fa-user"></span>
		            </div>
		          </div>
		        </div>
		        <div class="input-group mb-3">
		          <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" style="font-family: candara">
		          <div class="input-group-append">
		            <div class="input-group-text">
		              <span class="fas fa-envelope"></span>
		            </div>
		          </div>
		        </div>
		        <div class="input-group mb-3">
		          <input type="text" class="form-control" name="phonenumber" placeholder="PhoneNumber" value="<?php echo e(old('phonenumber')); ?>" style="font-family: candara">
		          <div class="input-group-append">
		            <div class="input-group-text">
		              <span class="fas fa-phone"></span>
		            </div>
		          </div>
		        </div>
		        <div class="input-group mb-3">
		          <input type="text" class="form-control" name="password" placeholder="Default Password" value="<?php echo e(old('password')); ?>" style="font-family: candara">
		          <div class="input-group-append">
		            <div class="input-group-text">
		              <span class="fas fa-key"></span>
		            </div>
		          </div>
		        </div>
		        <div class="input-group mb-3" >
		          <select class="form-control" name="role" style="font-family: candara">
		          	<option value="" selected>Pick User's Role</option>
		          	<option value="super_admin">super_admin</option>
		          	<option value="review_teamlead">review_teamlead</option>
		          	<option value="review_team_member">review_team_member</option>
		          	<option value="collection_teamlead">collection_teamlead</option>
		          	<option value="collection_team_member">collection_team_member</option>
		          	<option value="customer_care">customer_care</option>
		          	<option value="technician">technician</option>
		          	<option value="collection_team_member_S0">collection_team_member_S0</option>
		          	<option value="collection_team_member_S1">collection_team_member_S1</option>
		          	<option value="collection_team_member_S2">collection_team_member_S2</option>
		          	<option value="collection_team_member_M1">collection_team_member_M1</option>
		          	<option value="collection_team_member_m2">collection_team_member_M2</option>


		          	
		          	
		          	
		          </select>
		          
		        </div>
		        
		        <div class="row">
		          <div class="col-12">
		            <button type="submit" class="btn btn-success btn-block">Register</button>
		          <!-- /.col -->
		           <!-- /.col -->
		        </div>
		    	</div>
		      </form>

		      

		     
		    </div>
		    <!-- /.form-box -->
		  </div>
		</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wabloan.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\create_staff.blade.php ENDPATH**/ ?>