<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>WabLoan|Leading Enterprise</title>

  <!-- Google Font: Source Sans Pro -->
  <?php echo $__env->make('wabloan.includes.toplink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<div class="wrapper">

  <div class="modal fade" id="reassign" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Re-Assign</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                        <form class="" method="post" action="<?php echo e(route('reassign')); ?>">
                                            <?php echo csrf_field(); ?>
                                                    
                                            <div class="position-relative form-group"><label for="exampleSelect" class="">Review Team Members</label>
                                                
                                                <select class="form-control" name="reassign_select" id="reassign_select">
                                                    <option value="" selected>Reassign Role</option>
                                                  <?php if(!empty($review_memebers)): ?>  
                                                  <?php $__currentLoopData = $review_members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option value="<?php echo e($member->userid); ?>"><?php echo e($member->fname); ?> <?php echo e($member->lname); ?></option>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                  <?php endif; ?>
                                                </select>
                                            </div>
                                          <input type="hidden" name="id" id="loan_id">
                                          <button class="mt-1 btn btn-primary">Update</button>
                                        </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    
                                </div>
                            </div>
                        </div>
            </div>
            <div class="modal fade" id="review" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Review</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                        <form class="" method="post" action="<?php echo e(route('update_review_status')); ?>">
                                            <?php echo csrf_field(); ?>
                                                    
                                            <div class="position-relative form-group"><label for="exampleSelect" class="">Review </label>
                                                
                                                <select class="form-control" name="review_status" id="reassign_select">
                                                  <option value="" selected>Select Review Status </option>
                                                  <option value="Approved" >Approved </option>
                                                  <option value="Incomplete Information" >Incomplete Information </option>
                                                  <option value="Reapply in 30 days" >Reapply in 30 days</option>
                                                  <option value="Move to Blacklist" >Move to Blacklist</option>
                                                  
                                                </select>
                                            </div>
                                          <input type="hidden" name="userid" id="review_id">
                                          <button class="mt-1 btn btn-primary">Review</button>
                                        </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    
                                </div>
                            </div>
                        </div>
            </div>
  <!-- Navbar -->
  <?php echo $__env->make('wabloan.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
 
<?php echo $__env->make('wabloan.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    
    <!-- /.content-header -->

    <!-- Main content -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <?php echo $__env->make('wabloan.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->

</body>
</html>
<?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\layout\app.blade.php ENDPATH**/ ?>