<aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color: #282C35">
    <!-- Brand Logo -->
    <a href="#" class="brand-link" style="background-color: #282C35">
      
      <span class="brand-text font-weight-light" style="font-size: 14px;font-family: Impact">WabLoan</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('extensions/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block" ><?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?></a>
          <?php $__currentLoopData = Auth::user()->Roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <span style="color: #cccccc">(<?php echo e($role->name); ?>)</span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <?php if(Auth::user()->hasRole('super_admin')): ?>
          <li class="nav-item">
            <a href="<?php echo e(route('index')); ?>" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Dashboard
                <span class="right badge badge-danger">New</span>
              </p>
            </a>
          </li>
          
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Review Manager 
                <i class="fas fa-angle-left right"></i>
                
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('awaiting_loan_request')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Awaiting Loan Review</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('all_loan_order')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>All Order</p>
                </a>
              </li>

            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Collection Manager
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>All Due Loans</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Review_Collection_team_S0</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Review_Collection_team_S1</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/collection_team/all/due_loans/review/s_three" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Review_Collection_team_S2</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/collection_team/all/due_loans/review/m_one" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Review_Collection_team_M1</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/collection_team/all/due_loans/review/m_two" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Review_Collection_team_M2</p>
                </a>
              </li>
              
            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-tree"></i>
              <p>
                Customer Care
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>All Tickets</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Open Tickets</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Closed Tickets</p>
                </a>
              </li>
              
            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Technical Dept
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Order Review</p>
                </a>
              </li>
              
            </ul>
          </li>
          
          <li class="nav-header">Analytic Tools</li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-calendar-alt"></i>
              <p>
                  Report
                <span class="badge badge-info right">2</span>
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-image"></i>
              <p>
                Manage Users
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-envelope"></i>
              <p>
                Loan Management
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Review</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                User Profile Management
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.create_staff')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Create Staff</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Reset Password</p>
                </a>
              </li>
          
            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-plus-square"></i>
              <p>
                Manage Permission
                
              </p>
            </a>
            
          </li>
          
          
          
        </ul>
        <?php endif; ?>

        <?php if(Auth::user()->hasRole('review_team_member')): ?>
          <li class="nav-item"style="background-color: #bad555">
            <a href="<?php echo e(route('index')); ?>" class="nav-link">
              <i class="nav-icon fas fa-th" style="color:#fff "></i>
              <p style="color: #fff">
                My Review Order
                <span class="right badge badge-danger">New</span>
              </p>
            </a>
          </li>
          
          

        <?php endif; ?>


        <?php if(Auth::user()->hasRole('review_teamlead')): ?>
          <li class="nav-item" >
            <a href="<?php echo e(route('index')); ?>" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                My Review Order
                <span class="right badge badge-danger">New</span>
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Order
                <i class="fas fa-angle-left right"></i>
                
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('all_assigned_loan_order')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Reassign Order</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('all_loan_order')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>All Order</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                User Profile Management
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              
              <li class="nav-item">
                <a href="<?php echo e(route('changepassword')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Change Password</p>
                </a>
              </li>
          
            </ul>
          </li>

        <?php endif; ?>

        <?php if(Auth::user()->hasRole('collection_team_member_S0')): ?>
          
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Review Order
                
                
              </p>
            </a>
            
          </li>

        <?php endif; ?>

        <?php if(Auth::user()->hasRole('customer_care')): ?>
          <li class="nav-item">
            <a href="<?php echo e(route('index')); ?>" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Dashboard
                <span class="right badge badge-danger">New</span>
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Tickets
                <i class="fas fa-angle-left right"></i>
                
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('index')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Open Ticket</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('all_loan_order')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>All Tickets</p>
                </a>
              </li>
              
            
              
            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                User Profile Management
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              
              <li class="nav-item">
                <a href="<?php echo e(route('changepassword')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Change Password</p>
                </a>
              </li>
          
            </ul>
          </li>

        <?php endif; ?>

        <?php if(Auth::user()->hasRole('collection_team_member_S0')): ?>
        <li class="nav-item">
            <a href="<?php echo e(route('index')); ?>" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Dashboard
                <span class="right badge badge-danger">New</span>
              </p>
            </a>
          </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                User Profile Management
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              
              <li class="nav-item">
                <a href="<?php echo e(route('changepassword')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Change Password</p>
                </a>
              </li>
          
            </ul>
          </li>
        <?php endif; ?>

        <?php if(Auth::user()->hasRole('collection_team_member_S1')): ?>
        <li class="nav-item">
            <a href="<?php echo e(route('index')); ?>" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Dashboard
                <span class="right badge badge-danger">New</span>
              </p>
            </a>
          </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                User Profile Management
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              
              <li class="nav-item">
                <a href="<?php echo e(route('changepassword')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Change Password</p>
                </a>
              </li>
          
            </ul>
          </li>
        <?php endif; ?>

      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\includes\sidebar.blade.php ENDPATH**/ ?>