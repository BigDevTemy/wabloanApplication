
<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style type="text/css">
  
  /* Tabs*/
section {
    padding: 5px ;
}
.loader {
  border: 6px solid #f3f3f3; /* Light grey */
  border-top: 6px solid #3498db; /* Blue */
  border-radius: 50%;
  width: 50px;
  height: 50px;
  animation: spin 2s linear infinite;
  position: absolute;
  margin-left: 30%;
  margin-top: 20%;
}

@keyframes  spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

section .section-title {
    text-align: center;
    color: #007b5e;
    margin-bottom: 20px;
    text-transform: uppercase;
}
#tabs{
  background-color: #f3f3f3;
    color: #000;
    font-family: 'candara';
    font-size: 14px;
}
#tabs h6.section-title{
    color: #fff;
}

#tabs .nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link.active {
    color: #000000;
    background-color: transparent;
    border-color: transparent transparent #000000;
    border-bottom: 4px solid !important;
    font-size: 12px;

    font-weight: bold;
}
#tabs .nav-tabs .nav-link {
    border: 1px solid transparent;
    border-top-left-radius: .25rem;
    border-top-right-radius: .25rem;
    color: #000;
    font-size: 12px;
    font-family: 'candara';
}
</style>
<div  id="loader"></div>

<section class="content">
  <div id="content" class="row" style="background-color: #fff;position: relative;display: none;">
       

        
            

            <div class="row" style="background-color: ">
              <div class="col-md-12"><h5 style="font-family: candara">Order Resources</h5></div>
                <div class="col-md-4">
                  <div class="row" style="">
                    <div class="col-md-6" style="font-family: candara;"><div class="form-group">Order Resources:</div></div>
                    <div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;"><h3>Wabloan</h3></div>
                  </div>
                  
                  <div class="row" style="margin-top: 10px">
                    <div class="col-md-6" style="font-family: candara">Order No:</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">123456</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Loan Amount :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">100,000</div>
                  </div>

                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Loan Term :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                </div>
                
                <div class="col-4">
                  <div style="">
                    <div class="row" style="">
                    <div class="col-md-6" style="font-family: candara"><div class="form-group">Order Status:</div></div>
                    <div class="col-md-6" style="font-family: candara;;color: #bad555;font-weight: bold;"><h3>unpaid</h3></div>
                  </div>
                  
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Created Time:</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">123456</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Disbursement Date :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">100,000</div>
                  </div>

                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Due Date :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                    <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Interest Rate:</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Overdue date :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Overdue days :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                  </div>
                </div>
                <div class="col-4">
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Due Amount :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Penalty :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Total Due Amount :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Repayment Amount :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara"> Remaining Balance :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                </div>
          </div>

          <div class="row" style="margin-top: 20px;">
            <div class="col-md-6">
              <div style="font-family: candara;font-size: 14px;font-weight: bold;width: 100%">Repayment amount in the next 7days</div>
            </div>
            

          </div>

          <div class="row" style="margin-top: 20px;">
            <div class="col-md-6">
              <div style="font-family: candara;font-size: 14px;font-weight: bold;width: 100vh">Photo Display</div>
            </div>
            <div class="col-md-6">
              <img src="<?php echo e(asset('extensions/images/img.jpg')); ?>" style="width: 200px;height: 200px" />
            </div>

          </div>
          <div class="row" style="margin-top: 20px;width: 100vh;margin: 5">
            <div class="col-md-12">
              <div style="font-family: candara;font-size: 14px;font-weight: bold;width: 100vh;">Verification management</div>
              <div style="width:100%" align="center"><button style="background-color: #bad555;color: #fff;border:1px solid #bad555">Manual Audit</button></div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-12">
            
            <h1>Loan History</h1>
            <div class="table-responsive">
                  

                    <table class="table m-0">
                      <thead>
                      <tr style="font-family: candara;font-size: 12px">
                         <th>#</th>
                        <th>Order Number</th>
                        <th>Order Status</th>
                        <th>Loan Amount</th>
                        <th>Borrowing Period</th>
                        <th>Date of Arrrival</th>
                        <th>Repayment Date</th>
                        <th>Actual Repayment Date</th>
                        <th>Amount Due</th>
                        <th>Repaid Amount</th>
                        <th>Remain Amount</th>
                        <th>Coupon Amount</th>
                        <th>Reviewer</th>
                        <th>Review Time</th>
                        <th>Review Details</th>
                      </tr>
                      </thead>
                      <tbody>
            
                      <tr>
                        
                
                        
                      </tr>
                      
                      </tbody>
                    </table>
                </div>
          </div>
          
          

        </div>

    
      </div>

      <div id="content_personal" style="display: none;">
          <div class="row" style="width:100%">
              <div class="col-md-12" style="margin-top: 30px"><h5 style="font-family: candara">Personal Information</h5></div>
                <div class="col-md-4">
                  <div class="row" style="">
                    <div class="col-md-6" style="font-family: candara;"><div class="form-group">Source:</div></div>
                    <div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;"><h3>Wabloan</h3></div>
                  </div>
                  
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Limit:</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">123456</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Level :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">100,000</div>
                  </div>

                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Source :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Customer type :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                </div>
                
                <div class="col-4" >
                  <div style="">
                    <div class="row" style="">
                    <div class="col-md-6" style="font-family: candara"><div class="form-group">Name:</div></div>
                    <div class="col-md-6" style="font-family: candara;;color: #bad555;font-weight: bold;">Odewumi Temiloluwa</div>
                  </div>
                  
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Gender:</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">Male</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Age :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">30</div>
                  </div>

                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Birthday :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">June 8 1990</div>
                  </div>
                    <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Marital Status:</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5days</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Number of Children :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;"></div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Phonenumber :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">09072419909</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Email :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">hademylola@gmail.com</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Registered Date :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">Sept 23rd 2020</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">ID Number :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">Sept 23rd 2020</div>
                  </div>
                  </div>
                </div>
                <div class="col-4">
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Family Member Relation :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">Spouse</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Family Member Name :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">Oluwakemi Famiyi</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Family Member Number :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">09088877765</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Other Contact Person Name:</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">Temiloluwa Geoffrey</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Other Contact Person Number :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">09072413343</div>
                  </div>
                  
                </div>
          </div>
          <div class="row" style="margin-top: 10px;">
            <div class="col-md-6">
              <div class="row"><span style="font-weight: bold;font-family: candara">BVN Information</span></div>
              <div style="width:100%" align="center">
                <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Name :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">Temiloluwa</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Gender :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">Male</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">BVN NO :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">22222222222</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Registered Phone Number :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">09076544432</div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">BVN phonenumber :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">09076544432</div>
                  </div>
                  
              </div>
            </div>
            <div class="col-md-6">
              <div class="row"><span style="font-weight: bold;font-family: candara">Address Information</span></div>
              <div style="width:100%" align="center">
                <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Plot :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;"></div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Street :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;"></div>
                  </div>
                  
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">City Town :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;"></div>
                  </div>
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Nearest Bus Stop :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;"></div>
                  </div>
                  
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Local Government Area(LGA) :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;"></div>
                  </div>
                  
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">State :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">OYO STATE</div>
                  </div>
                  
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Live Year :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">5</div>
                  </div>
                  
                  <div class="row" style="margin-top: 20px">
                    <div class="col-md-6" style="font-family: candara">Live Month :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">60</div>
                  </div>
                  

              </div>
            </div>
          </div>

      </div>

  <div class="container-fluid">
    <div class="row">
      
      
      <section id="tabs">

        <div class="container">
          <div class="row">
            <nav>
                
                <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist" >
                    
                </div>
              </nav>
            </div>
            <div class="row">
                <div id="loader_Ajax"></div>
                 <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent" >
          
            
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab" style="width:100%;height:100%;background-color: #fff">
                        
                    </div>
                  </div>
            </div>
          </div>
      </section>

    </div>      
      
  </div>
      

        
        
         

    </section>
<script type="text/javascript">
  $(document).ready(function(){
    $('#close').click(function(){
      $(".container-fluid").html('');
    })

    $('#review_member_table tbody').on('click', 'tr', function () {
    
        
         var data = $(this).find('input').attr('id').valueOf()
         
         
         document.getElementById('review_id').value = data;
  
         
    } );

    var getassigned = <?php echo json_encode($getassigned, 15, 512) ?>;
    var get_all_loan = <?php echo json_encode($get_all_loan, 15, 512) ?>;
    var getallUsers = <?php echo json_encode($getallUsers, 15, 512) ?>;
    console.log('getassigned',getassigned);
    var check_home=0;
    var check_details=0;
    var load_home_content =  function (){

      $("#close_home").click(function(){
        $("#nav-home-tab").remove();
        $("#nav-home").html('')
      })
      $content_Tab = '<div style="80%;"><div class="row"><div class="col-md-2"><div class="form-group-group"><label for="ordersearch"style="font-family: candara">Order Search</label><input type="text" class="form-control"  id="ordersearch" name="ordersearch" placeholder="bvn/name/phonenumber/loanid" value="" style="font-family: candara"></div></div><div class="col-md-4"><div class="row"><div class="col-md-6"><div class="form-group"><label style="font-family: candara">Start Date </label><input type="date" class="form-control" id="start_date"  name="start_date" placeholder="" value="" style="font-family: candara"></div> </div><div class="col-md-6"><div class="form-group"><label style="font-family: candara">End Date</label><input type="date" id="end_date" class="form-control"  name="end_date" placeholder="" value="" style="font-family: candara"></div> </div></div></div><div class="col-md-2"><div class="form-group"><label style="font-family: candara">App Type</label><select class="form-control"  id="apptype" name="apptype" style="font-family: candara"><option selected>please select one</option><option value="wabloan">wabloan</option></select></div></div></div><div class="row"><div class="col-md-2"><div class="form-group"><label style="font-family: candara">Loan Status</label><select class="form-control" name="loanstatus" id="loanstatus" style="font-family: candara"><option selected>please select one</option><option value="paid">paid</option><option value="unpaid">unpaid</option></select></div></div><div class="col-md-2"><div class="form-group"><label style="font-family: candara">Return Reason</label><select class="form-control" id="return_reason" name="return_reason" style="font-family: candara" ><option selected>please select one</option><option value="Approved" >Approved </option><option value="Incomplete Information" >Incomplete Information </option><option value="Reapply in 30 days" >Reapply in 30 days</option><option value="Move to Blacklist" >Move to Blacklist</option></select></div></div><div class="col-md-2"><div class="form-group"><label style="font-family: candara">Order Sort</label><select class="form-control" id="order_sort" name="order_sort" style="font-family: candara"><option value="" selected>please select one</option><option value="loanID">Loan ID</option><option value="loan_status">Loan Status</option><option value="assignTo">Reviewer</option></select></div></div></div><div id="table"></div></div>'

      
      $("#nav-home").html($content_Tab)
      table_content(getassigned);

       $("#tab1").click(function(){
        var id =$(this).find('input').attr('value').valueOf();
        var userid =$(this).find('input').attr('name').valueOf();
            if(check_details > 0){
              $("#nav-home-tab").css('background-color','#fff')
              $("#nav-home-tab").css('color','#fff')
              $("#nav-details-tab").css('background-color','#bad555')
              $("#nav-details-tab").css('color','#000')
              load_details_content(id,userid);
        }
        else{
          var id =$(this).find('input').attr('value').valueOf();
          var userid =$(this).find('input').attr('name').valueOf();
            $tab_Details = '<a class="nav-item nav-link active" id="nav-details-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true" style="background-color: #bad555;color: #000;margin-left:5px"><span style="color:#000">Details</span> <i class="fas fa-times" style="color:#000;margin-left:5px" id="close_details"></i></a>'
            $(".nav-tabs").append($tab_Details)
            $("#nav-home-tab").css('background-color','#fff')
            $("#nav-home-tab").css('color','#fff')
            load_details_content(id,userid);
            check_details=1

            $("#nav-details-tab").click(function(){
              $(this).css('background-color','#bad555')
              $(this).css('color','#000')
              $("#nav-home-tab").css('background-color','#fff')
              $("#nav-home-tab").css('color','#fff')

              load_details_content(id,userid);

            })

              $("#close_details").click(function(){
                if(check_home > 0){
                  
                $("#nav-details-tab").remove();
                $('#nav-home-tab').css('background-color','#bad555')
                $('#nav-home-tab').css('color','#000')
                $("#nav-home").html('')
                load_home_content();
                
                check_details=0
                }
                else{
                $("#nav-details-tab").remove();
                $("#nav-home").html('')
                check_details=0
                }
              
            })
          }
        

      })


    }

    var loan_information = function(id,userid){
       var filterLoan = get_all_loan.filter(function(el){
        return el.id == id;
      })

       var filterLoanHistory = get_all_loan.filter(function(el){
        return el.userId == userid;
      })

       console.log('filterLoanHistoryyyy',filterLoanHistory)
       $.each(filterLoan,function(index,value){
        
        
          $dataset = '<div style=";margin-left:15px" ><div class="row"><span style="font-family:candara;font-size:16px;font-weight:bold;margin-left:15px;margin-top:30px">Order Resources</span></div><div class="row" style=""><div class="col-md-4"><div class="row"><div class="col-md-6">Order Resources:</div><div style="font-family:candara;color:#bad555" class="col-md-6">Wabloan</div></div><div class="row"><div class="col-md-6">Order No:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.loanID+'</div></div><div class="row"><div class="col-md-6">Loan Amount:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.loan_amount+'</div></div><div class="row"><div class="col-md-6">Loan Term:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.loan_tenure+'</div></div></div><div class="col-md-4"><div class="row"><div class="col-md-6">Order Status:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.loan_status+'</div></div><div class="row"><div class="col-md-6">Created Time:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.created_at+'</div></div><div class="row"><div class="col-md-6">Disbursement date:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.updated_at+'</div></div><div class="row"><div class="col-md-6">Due Date date:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.due_date+'</div></div><div class="row"><div class="col-md-6">Interest Rate:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.loan_interest+'</div></div><div class="row"><div class="col-md-6">Overdue date:</div><div style="font-family:candara;color:#bad555" class="col-md-6"></div></div><div class="row" style="margin-bottom:30px"><div class="col-md-6">Overdue date:</div><div style="font-family:candara;color:#bad555" class="col-md-6"></div></div></div><div class="col-md-4"><div class="row"><div class="col-md-6">Due Amount:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.loan_total+'</div></div><div class="row"><div class="col-md-6">Due Amount:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.loan_amount+'</div></div><div class="row"><div class="col-md-6">Penalty:</div><div style="font-family:candara;color:#bad555" class="col-md-6"></div></div><div class="row"><div class="col-md-6">Total Due Amount:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.loan_amount+'</div></div><div class="row" ><div class="col-md-6">Due Amount:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.loan_total+'</div></div><div class="row"><div class="col-md-6">Repayment Amount:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.repayment_amount+'</div></div><div class="row" style="margin-bottom:30px"><div class="col-md-6">Remaining Balance:</div><div style="font-family:candara;color:#bad555" class="col-md-6">'+value.balance+'</div></div></div><div class="row" style="margin-bottom:30px;background-color:#f4f4f4;width:100%"><div class="col-md-12" style="font-family:candara;font-size16px;font-weight:bold;margin-left:15px">Repayment amount in the next 7days</div></div><div class="row" style="width:100%;margin-bottom:30px"><div class="col-md-6"><div style="font-weight:bold;font-size:18px;margin-left:15px">Photo Display</div></div><div class="col-md-6"><img src="<?php echo e(asset("wabloan_selfie/1602643319F250E344-371B-4637-BA37-BCB99D840C52.jpg")); ?>" style="width:200px;height:200px"/><img src="<?php echo e(asset("wabloan_selfie/1602185510AAFC288B-286A-41A7-BED7-AFF0B76FB0D1.jpg")); ?>" style="width:200px;height:200px;margin-left:20px" alt="'+value.user.imageurl+'"/></div></div><div class="row" style="width:100%;background-color:#f4f4f4;margin-bottom:30px"><div class="col-md-12" style="font-weight:bold;font-size:16px;font-family:candara;margin-left:15px;">Verification management</div><div class="row" style="width:100%"><div class="col-md-12" align="center" style="width:100%"><button style="width:100px;height:30px;background-color:#bad555;border:1px solid #bad555;color:#fff">Manual Audit</button></div></div></div><div class="row" style="width:100%"><div class="row" style="width:100%"><div class="col-md-6" style="font-size:20px;font-weight:bold;font-family:candara"><div style="margin-left:30px;width:100%;">Loan History</div></div><div class="col-md-6" >Successful</div></div><div class="row"><div class="col-md-12" style="margin-left"><div class="table-responsive"><table class="table m-0"><thead><tr style="font-family: candara;font-size: 12px"><th>#</th><th>Order Number</th><th>Order Status</th><th>Loan Amount</th><th>Borrowing Period</th><th>Date of Arrrival</th><th>Repayment Date</th><th>Actual Repayment Date</th><th>Amount Due</th><th>Repaid Amount</th><th>Remain Amount</th><th>Coupon Amount</th><th>Reviewer</th><th>Review Time</th><th>Review Details</th></tr></thead><tbody id="tbody-loan-history"></tbody></table></div></div></div></div></div></div>'
          
       })
          $("#nav-home-sub").html('');
        $("#nav-home-sub").html($dataset).show(500)
      
      //$('#nav-home-sub').hide().html($("#content").html()).show(500);
      $.each(filterLoanHistory,function(index,value){
        $datasetLoans ='<tr><td>'+value.id+'</td><td>'+value.loanID+'</td><td>'+value.loan_status+'</td><td>'+value.loan_amount+'</td><td>'+value.loan_tenure+'</td><td>'+value.created_at+'</td><td>'+value.due_date+'</td><td>'+value.due_date+'</td><td>'+value.loan_total+'</td><td>'+value.balance+'</td><td>'+value.balance+'</td><td>null</td><td>'+value.assignTo+'</td><td>'+value.updated_at+'</td><td>'+value.review_status+'</td></tr>'
          $("#tbody-loan-history").append($datasetLoans).show(500)
      })

    }
    var personal_information = function(id,userid){
      var filterUserDetails = getallUsers.filter(function(el){
        return el.userid == userid;
      })
      
        $.each(filterUserDetails,function(index,value){
          $dataset = '<div style="margin-left:15px"><div class="row" style="width:100%"><div class="col-md-12" style="margin-top: 30px;background-color:#fff"><h5 style="font-family: candara">Personal Information</h5></div><div class="col-md-4"><div class="row" style=""><div class="col-md-6" style="font-family: candara;"><div class="form-group">Source:</div></div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;"><h3>Wabloan</h3></div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Limit:</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.credit_limit+'</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Level :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.credit_limit+'</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Source :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">null</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Customer type :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">null</div></div></div><div class="col-4" ><div class="row" ><div class="col-md-6" style="font-family: candara"><div class="form-group">Name:</div></div><div class="col-md-6" style="font-family: candara;;color: #bad555;font-weight: bold;">'+value.fname+'</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Gender:</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">Male</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Age :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.dob+'</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Birthday :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.dob+'</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Marital Status:</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.marital_status+'</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Number of Children :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;"></div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Phonenumber :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.phonenumber+'</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Email :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.email+'</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Registered Date :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.created_at+'</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">ID Number :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;margin-bottom:30px">'+value.id+'</div></div></div><div class="col-4"><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Family Member Relation :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">null</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Family Member Name :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">Oluwakemi Famiyi</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Family Member Number :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.familycontact+'</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Other Contact Person Name:</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">Temiloluwa Geoffrey</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Other Contact Person Number :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.friendcontact+'</div></div></div><div class="row" style="width:100%;"><div class="col-md-6" style="background-color:#fff"><div class="row" style="width:100%"><div style="font-weight: bold;font-family: candara;margin-top:30px;margin-left:15px">BVN Information</span></div><div style="width:100%;background-color:#fff" align="center" ><div class="row" style="margin-top:20px"><div class="col-md-6" style="font-family: candara">Name :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.fname+' '+ value.lname +'</div></div><div class="row" style="margin-top:20px"><div class="col-md-6" style="font-family: candara">Gender :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">Male</div></div><div class="row" style="margin-top:20px"><div class="col-md-6" style="font-family: candara">BVN NO :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.bvn+'</div></div><div class="row" style="margin-top:20px" ><div class="col-md-6" style="font-family: candara">Registered Phone Number :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.phonenumber+'</div></div><div class="row" style="margin-top:20px"><div class="col-md-6" style="font-family: candara">BVN phonenumber :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.phonenumber+'</div></div></div></div></div><div class="col-md-6" style="background-color:#fff"><div class="row" style="margin-top:20px"><span style="font-weight: bold;font-family: candara">Address Information</span></div><div style="width:100%" align="center"><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Plot :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">null</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Street :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">null</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">City Town :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;"></div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Nearest Bus Stop :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">null</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Local Government Area(LGA) :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;"></div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">State :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">'+value.state+'</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Live Year :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">null</div></div><div class="row" style="margin-top: 20px"><div class="col-md-6" style="font-family: candara">Live Month :</div><div class="col-md-6" style="font-family: candara;color: #bad555;font-weight: bold;">null</div></div></div></div></div></div></div>'
          
        })
      $("#nav-profile").html($dataset)

      $("#nav-home-loan").click(function(){
        $("#nav-profile").html('')
        $('#nav-profile').html('Temiloluwa')
        loan_information(id,userid);
        //$('#nav-home-sub').hide().html($("#content_personal").html()).show(500);

      })
      
    }

    var table_content = function (assigned){

      var  dataset = '<div class="row"><div class="col-md-8"><div style="width:100%" align="center"><input type="submit" name="" id="search" value="Search" class="btn btn-info" style="width:100px;margin:5px;background-color: #bad555;border-color: #bad555;font-family: candara"/> <button type="button" class="btn btn-info" style="width:100px;margin:5px" >Refresh</button></div></div></div><div class="row" style=""><div class="col-md-9" style="overflow-x:auto"><table id="review_member_table" class="table table-striped table-bordered" style="background-color: #fff;"><thead><tr style="font-family: candara;font-size:12px"><th>#</th><th>app type</th><th>Order No</th><th>Customer Name</th><th>Mobile number</th><th>BVN</th><th>Loan Amount</th><th>Loan Term</th><th>Order Created Time</th><th>Success Repayment Count</th><th>Loan Status</th><th>Risk Rule Result</th><th>Reviewer</th><th>Review Time</th><th>Review Details</th><th>Disapproval Reason</th><th>Pending Time</th><th>Operation</th></tr></thead><tbody id="tbody"></tbody></table></div></div>'

        $("#table").html(dataset)
      
        


  
        $.each(assigned,function(index,value){
          var dataset = '<tr><td style="font-family:candara;font-size:12px">'+value['id']+'</td><td  style="font-family:candara;font-size:12px">Wabloan</td><td  style="font-family:candara;font-size:12px">'+value['loanID']+'</td><td  style="font-family:candara;font-size:12px">'+value['fullname']+'</td><td  style="font-family:candara;font-size:12px">'+value['phonenumber']+'</td><td  style="font-family:candara;font-size:12px">'+value['bvn']+'</td><td>'+value['loan_amount']+'</td><td  style="font-family:candara;font-size:12px">'+value['loan_tenure']+'</td><td  style="font-family:candara;font-size:12px">'+value['created_at']+'</td><td  style="font-family:candara;font-size:12px">0</td><td>'+value['loan_status']+'</td><td><div class="badge badge-success">warning</div></td><td  style="font-family:candara;font-size:12px">'+value['assignTo']+'</td><td  style="font-family:candara;font-size:12px">'+value['created_at']+'</td><td  style="font-family:candara;font-size:12px">'+value['review_status']+'</td><td  style="font-family:candara;font-size:12px">'+value['review_status']+'</td><td  style="font-family:candara;font-size:12px">'+value['loanID']+'</td><td><div class="" style="cursor:pointer;" data-toggle="modal" data-target="#review" id="review_review"><div  style="background-color: #bad555;color:#fff;margin-bottom: 10px;width: 70px;height: 30px;border-radius: 5px;line-height: 25px" align="center"><input type="hidden" value="'+value['id']+'" name="'+value['userId']+'" />Review</div><div class="" style="cursor:pointer;" data-toggle="modal" data-target="#"></div></div><div  style="background-color: #1464f4;color:#fff;margin-bottom: 10px;width: 70px;height: 30px;border-radius: 5px;line-height: 25px" align="center" id="tab1"><input type="hidden" value="'+value['id']+'" name="'+value['userId']+'" />Details</div></td></tr>'
          $('#tbody').append(dataset);
          
        })

        $("#review_review").click(function(){
          var userid= $(this).find('input').attr('name').valueOf();
          document.getElementById('review_id').value= userid
        })

        $("#search").click(function(){
          var ordersearch = document.getElementById('ordersearch').value;
          var start_date = document.getElementById('start_date').value;
          var end_date = document.getElementById('end_date').value;
          var apptype = document.getElementById('apptype').value;
          var loan_status = document.getElementById('loanstatus').value;
          var return_reason = document.getElementById('return_reason').value;
          var order_sort = document.getElementById('order_sort').value;
          $.ajax({
              url:'<?php echo e(route("search_review")); ?>',
              type:'post',
              headers: { 'X-CSRF-TOKEN': $('input[name=_token]').val() },
              beforeSend: function() {
                $('#loader_Ajax').addClass('loader');    
              },
                data:{
                      ordersearch:ordersearch,
                      start_date:start_date,
                      end_date:end_date,
                      apptype:apptype,
                      loanstatus:loan_status,
                      return_reason:return_reason,
                      order_sort:order_sort,
                      "_token": "<?php echo e(csrf_token()); ?>"        
                    },
                success:function(data){
                          console.log('data',data)
                          $("#loader_Ajax").removeClass('loader');
                      if(data['status'] == 'success'){
                        
                        
                        table_content(data['data']);
                      }
                      if(data['status']== 'failed'){
                        
                        alert(data['data'])
                      }

                      },
                error:function(object, status, e){
                      alert(e);
                                
                      }

                    })
          
          
        
        })
    }
    
    var load_details_content = function (id,userid){
      $content_div_details = '<div class="row"><section id="tabs"><div class="container"><div class="row"><nav><div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist" ><a class="nav-item nav-link active" id="nav-home-loan" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Loan Information</a><a class="nav-item nav-link" id="nav-profile-personal" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Personal Information</a><a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Transaction Information</a><a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Collection Information</a><a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Credit Information</a><a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Risk Information</a></div></nav></div><div class="row"><div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent" ><div class="tab-pane fade show active" id="nav-home-sub" role="tabpanel" aria-labelledby="nav-home-tab" style="width:150vh;height:100%;background-color: #fff;margin-left:2%"></div><div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" style="width:150vh;height:100%;background-color: #fff;margin-left:2%" ></div></div></div></div></section></div>'
      $content_details = '<div style="width:100%;">Tab2</div>'
      
      $("#nav-home").html($content_div_details)
      loan_information(id,userid);
      //$('#nav-home-sub').hide().html($("#content").html()).show(500);
      
      $("#nav-profile-personal").click(function(){
        
        personal_information(id,userid);
        //$('#nav-home-sub').hide().html($("#content_personal").html()).show(500);

      })
      $("#nav-home-loan").click(function(){
        
        loan_information(id,userid);
        //$('#nav-home-sub').hide().html($("#content_personal").html()).show(500);

      })
    }



    $(".nav-tabs").append('<a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true" style="background-color: #bad555;color: #000"><span style="color: #000">New Order</span> <i class="fas fa-times" style="color:#000;margin-left:5px" id="close_home"></i></a>')
      load_home_content ()
      check_home=1;


    $("#close_home").click(function(){

      if(check_details > 0){
        $("#nav-home-tab").remove();
        $("#nav-home").html('')
        load_details_content();
        check_home=0;
      }
      else{
        $("#nav-home-tab").remove();
        $("#nav-home").html('')
      }
      
    })

   


    $("#nav-home-tab").click(function(){
      
      $(this).css('background-color','#bad555')
      $(this).css('color','#000')
      $("#nav-details-tab").css('background-color','#fff')
      $("#nav-details-tab").css('color','#fff')
      load_home_content();
      check_home=1
      $("#tab1").click(function(){
        var id = $(this).find('input').attr('value').valueOf();

        
      if(check_details > 0){
        $("#nav-home-tab").css('background-color','#fff')
        $("#nav-home-tab").css('color','#fff')
        $("#nav-details-tab").css('background-color','#bad555')
        $("#nav-details-tab").css('color','#000')
        load_details_content();
      }
      else{
        $tab_Details = '<a class="nav-item nav-link active" id="nav-details-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true" style="background-color: #bad555;color: #000;margin-left:5px"><span style="color:#000">Details</span> <i class="fas fa-times" style="color:#000;margin-left:5px" id="close_details"></i></a>'
      $(".nav-tabs").append($tab_Details)
      $("#nav-home-tab").css('background-color','#fff')
      $("#nav-home-tab").css('color','#fff')
      load_details_content();
      check_details=1

      $("#nav-details-tab").click(function(){
        $(this).css('background-color','#bad555')
        $(this).css('color','#000')
        $("#nav-home-tab").css('background-color','#fff')
        $("#nav-home-tab").css('color','#fff')

        load_details_content();

      })

      $("#close_details").click(function(){
        if(check_home > 0){
          
        $("#nav-details-tab").remove();
        $('#nav-home-tab').css('background-color','#bad555')
        $('#nav-home-tab').css('color','#000')
        $("#nav-home").html('')
        load_home_content();
        
        check_details=0
        }
        else{
        $("#nav-details-tab").remove();
        $("#nav-home").html('')
        check_details=0
        }
        
      })
      }
      

    })

    })

    

    
  })
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('wabloan.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\review_member.blade.php ENDPATH**/ ?>