<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table style="width:100%;height: 100vh">
	<tr>
		<td style="width: 50%">
			Dear <strong><?php echo e($data[1]); ?></strong>
			<p style="font-family:'candara'">Thank you for Choosing Wabloan!</p>
			<p style="font-family:'candara'">This is to notify you that your TICKET (<?php echo e($data[0]); ?>) has been successfully submitted with us.
				Your request will be attended to shortly.<br/><br/>
			<span style="color: #8B0000">One of our Agent is currently working on this and a feedback will be given in a jiffy.</span>


			</p>

			<p><div style="margin-top:10%;width:100%;background-color: #dedede;font-family: 'candara'" align="center">
				Please Contact us at<br/>
				<a href="support@wabloan.com">support@wabloan.com</a> or by phone on<br/>
				09077766654
			</div></p>
			<p style="font-family: 'candara'">Yours Truly, <strong>Temi</strong></p>
			<p style="font-family: 'candara'">website:<a href="https://www.wabloan.com" style="color: #bad555">https://www.wabloan.com</a></p>

		</td>
		<td style="width: 50%">
			<div style="width: 100%;margin-top: 10%"  align="center">
				<img src="https://0eb6f0034276.ngrok.io/wabloan_selfie/logo_wabloan.png" style="width:50%" />	
			</div>
			
		</td>
	</tr>
</table>

</body>
</html><?php /**PATH C:\Users\USER\Desktop\wabloanApi\resources\views\wabloan\email\ticketmail.blade.php ENDPATH**/ ?>